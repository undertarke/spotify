export const TabTitle = (newTitle) => (document.title = newTitle);
