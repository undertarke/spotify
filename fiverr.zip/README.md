# Dự án cuối khoá Front-End Bootcamp 30

Dự án Fiverr

## Demo dự án Fiverr

### Các chức năng

. Xem danh sách công việc

. Xem các loại công việc

. Xem chi tiết loại công việc

. Xem chi tiết loại dịch vụ

. Đăng kí thuê các loại công việc

. Tạo tài khoản và đăng nhập

. Xem và Sửa thông tin tài khoản

. Xem và Sửa các loại công việc đã thuê

## Demo dự án Fiverr

Tài khoản test chức năng user :

Tài khoản: jhon1@gmail.com

Mật khẩu : 123123

Tài khoản test chức năng admin :

Tài khoản: dhau99@gmail.com

Mật khẩu : 123123

### Các chức năng

1.  Quản lí người dùng

    . Thêm, xoá, sửa thông tin người dùng

    . Thêm, xoá công việc muốn thuê

2.  Quản lí công việc

    . Thêm, xoá, sửa công việc

    . Thêm, xoá, sửa loại công việc

    . Thêm, xoá, sửa các dịch vụ

## Thành viên làm dự án Fiverr

. Nguyễn Đình Hậu ( jobTitle, jobDetail, Categories , Login, Register, userDetail, Result , admin )

. Nguyễn Văn Đức ( index )

. Nguyễn Duy Khang (jobDetail, Categories, Admin, Result )
