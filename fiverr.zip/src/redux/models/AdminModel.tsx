export interface ThemAdmin {
  name: string;
  email: string;
  password: string;
  phone: string;
  role: string;
}
