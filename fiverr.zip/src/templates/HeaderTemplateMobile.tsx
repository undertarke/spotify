import React from 'react'

type Props = {}

export default function HeaderTemplateMobile({}: Props) {
  return (
    <div>HeaderTemplateMobile</div>
  )
}